﻿ 
class clase_semana8_actividad_1
{
    static int numero;
    static void Main()
    {
        Console.WriteLine("Por favor, escriba un número positivo:");
        string? entrada = Console.ReadLine();
        if (int.TryParse(entrada, out int num))
        {
            numero = num;
            
            if(numero < 0)
            {
                Console.WriteLine(numero + " no es positivo");
            }
            else 
            {
                int resultado = CalcularFactorial(numero);
                Console.WriteLine("El factorial de " + numero + " es igual a " + resultado);
            }
        }
        else
        {
            Console.WriteLine("Conversión fallida.");
        }

    }

    static public int CalcularFactorial(int fact)
    {
        if(fact == 0)
        {
            return 1;
        }
        else
        {
            int factorial = 1;
            for (int i = 1; i <= fact; i++)
            {
                factorial = factorial * i;
            }
            return factorial;
        }
        
    }
}
 