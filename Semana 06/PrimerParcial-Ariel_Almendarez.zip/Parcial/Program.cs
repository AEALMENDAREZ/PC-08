﻿// See https://aka.ms/new-console-template for more information
int número1, número2, número3;

Console.WriteLine("Ingrese número 1");
número1 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese número 2");
número2 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese número 3");
número3 = Convert.ToInt32(Console.ReadLine());

if(número1 % 2 == 0)
{
    Console.WriteLine("Número 1 es par");
}
else
{
    Console.WriteLine("Número 1 es impar");
}
if(número2 % 2 == 0)
{
    Console.WriteLine("Número 2 es par");
}
else
{
    Console.WriteLine("Número 2 es impar");
}
if(número1 % 3 == 0)
{
    Console.WriteLine("Número 3 es par");
}
else
{
    Console.WriteLine("Número 3 es impar");
}