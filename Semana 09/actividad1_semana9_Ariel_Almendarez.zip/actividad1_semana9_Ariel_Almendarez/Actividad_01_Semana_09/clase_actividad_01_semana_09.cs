﻿class clase_actividad_01_semana_09
{
   static void Main()
   {
        Console.WriteLine("Ariel Almendárez - 1074625");

        Console.WriteLine("Por favor, ingrese un número entero positivo no mayor a 6 dígitos");
        string? entrada = Console.ReadLine();
        int numero;
        if(int.TryParse(entrada, out numero) == false)
        {   
            Console.WriteLine("Número no reconocido");
            return;
        }

        if((numero > 0 && numero < 1000000) == false)
        {
            Console.WriteLine("El número no cumple con las condiciones establecidas");
            return;
        }

        if(numero == 1)
        {
            Console.WriteLine(numero + " no es un número primo.");
            return;
        }
 
        bool esPrimo = true;

        for (int i = 2; i < numero; i++)
        {
            if(numero % i == 0)
            {
                esPrimo = false;
                //Console.WriteLine(i);
            }
        }

        if(esPrimo)
        {
            Console.WriteLine(numero + " es un número primo.");
        }
        else
        {
            Console.WriteLine(numero + " no es un número primo.");
        }
   }
 
}